package excepciones;

public class NoCocinadoException extends Exception {

	public String mensajeError() {

		return "No Cocinado";
	}
}
